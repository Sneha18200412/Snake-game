# Snake_Game_Python
The classic Snake game was developed in Python, setting up the environment with Pygame. he
game loop was developed to manage surface, update the snake's position based on user input,
and check for collisions. The screen was continuously refreshed to show the updated game
state. Collision detection was also incorporated to end the game upon wall or self-collision,
continuously refreshing the screen.
• Developed the classic Snake game in Python using Pygame.
• Implemented game mechanics including Snake Movement, Collision detection
and HighScore Tracking.
• Ensure continuous screen refresh to display the updated game state and end
the game on collisions
